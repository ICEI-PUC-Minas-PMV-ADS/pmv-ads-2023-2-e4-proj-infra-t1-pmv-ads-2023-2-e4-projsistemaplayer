import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity, Dimensions, StyleSheet } from 'react-native';
import {useNavigation} from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import Novoinfluencer from './NovoInfluencer';

const { width, height } = Dimensions.get('window');



const InfluencerListScreen = () => {
  
  const [influencers, setInfluencers] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('https://cortafruta.site/indiquee/api.php');
        if (!response.ok) {
          const errorData = await response.text();
          throw new Error('Erro ao buscar dados da API: ' + errorData);
        }

        const data = await response.json();
        setInfluencers(data);
      } catch (error) {
        console.error(error.message);
      }
    };

    fetchData();
  }, []);

  return (
    <ScrollView style={styles.scrollView}>
      <View style={styles.container}>
        <View style={styles.content}>
          <Text style={styles.headerText}>Gestão De Influencers</Text>
          <Text style={styles.subHeaderText}>Lista de Influencers Cadastrados</Text>

          <View style={styles.tableHeader}>
            <Text style={styles.headerCell}>Email</Text>
            <Text style={styles.headerCell}>Saldo</Text>
            <Text style={styles.headerCell}>Revshare</Text>
            <Text style={styles.headerCell}>Saldo Fake</Text>
            <Text style={styles.headerCell}>Ação</Text>
          </View>

          {influencers.map((influencer, index) => (
            <View key={index} style={styles.tableRow}>
              <Text style={styles.tableCell}>{influencer.email}</Text>
              <Text style={styles.tableCell}>{influencer.saldo}</Text>
              <Text style={styles.tableCell}>{influencer.revshare}</Text>
              <Text style={styles.tableCell}>{influencer.saldoFake}</Text>
              <View style={styles.actionCell}>
                <TouchableOpacity style={styles.actionButton}>
                  <Text style={styles.buttonText}></Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.actionButton, styles.secondaryActionButton]}>
                  <Text style={styles.buttonText}></Text>
                </TouchableOpacity>
              </View>
            </View>
          ))}

          <TouchableOpacity style={styles.primaryButton}>
            <Text style={styles.primaryButtonText}>Gerar Novo Influencer</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  scrollView: {
    backgroundColor: 'red',
    flex: 1
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    padding: width * 0.05,
    backgroundColor: 'white',
    borderWidth: 2,
    borderColor: 'black',
    borderRadius: 12,
    width: width * 0.8,
  },
  headerText: {
    fontSize: width * 0.05,
    fontWeight: 'bold',
  },
  subHeaderText: {
    fontSize: width * 0.04,
    marginTop: 10,
  },
  tableHeader: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderColor: '#ddd',
    marginTop: 10,
    justifyContent: 'space-around',
  },
  headerCell: {
    fontSize: 11,
    flex: 1,
    padding: width * 0.01,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  tableRow: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderColor: '#ddd',
    marginTop: width * 0.01,
    alignItems: 'center',
    justifyContent: 'space-around',
  },
  tableCell: {
    flex: 1,
    padding: width * 0.015,
    textAlign: 'center',
    fontSize: 10,
  },
  actionCell: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
  },
  actionButton: {
    backgroundColor: '#4CAF50',
    borderRadius: 12,
    padding: width * 0.02,
    margin: width * 0.005,
    width: 17,
    height: 17,
  },
  secondaryActionButton: {
    backgroundColor: '#2196F3',
  },
  buttonText: {
    color: 'black',
  },
  primaryButton: {
    backgroundColor: '#2377d4',
    padding: width * 0.04,
    marginTop: width * 0.02,
    borderRadius: 12,
    alignItems: 'center',
  },
  primaryButtonText: {
    color: 'white',
  }
});

export default InfluencerListScreen;